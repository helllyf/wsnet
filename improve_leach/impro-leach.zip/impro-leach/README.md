# impro-leach
Improved Leach is a project in Omnet++ aiming to simulate a version of Leach with an improved Cluster Head (CH) selection scheme.
