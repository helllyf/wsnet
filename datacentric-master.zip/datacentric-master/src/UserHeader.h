



//#define NEIGHBOUR_ADDR unsigned long long
#define NEIGHBOUR_ADDR uint64_t
//#define NEIGHBOUR_ADDR uint64

#define SELF_INTERFACE 0
